/**
 * Unitary Tests for testing the correctness of Memory class methods
 * 
 * @author Nome e NMec do aluno 1
 * @author Nome e NMec do aluno 2
 * 
 * @version data
 */

import static java.lang.System.*;
import java.util.*;
import java.io.*;

public class TestMemoryTime
{
	public static void main (String[] args)
	{
		Scanner input = new Scanner(System.in);

		Memory<Time> memory = null;
		
		Time time; // element being processed

		/* Make a test with times.csv (8 times in a memory with size 10)
		/* Make a test with empty.csv (empty memory - 0 times in a memory with size 10 */
		out.printf ("\nMaking tests with times.csv and with empty.csv\n");
		try
		{
			memory = loadMemoryFile ();
		}
		catch (IOException e)
		{
			out.printf ("%s\n", e.getMessage ());
			exit (1);
		}

		out.printf ("\nMemory read from the file\n");
		out.printf ("%s\n", memory.toString());

		// Testing the smallerElement method
		out.printf ("\nTesting the smallerElement method\n");
		Time smaller = null;
		try
		{
			smaller = memory.smallerElement ();
			out.printf("Smaller time in memory is %s\n", smaller.toString());
			assert smaller.toString().equals("00:00:00") : "Problems in the smaller method";
		}
		catch (MemoryEmptyException e)
		{
			out.printf ("%s\n", e.getMessage ());
		}

		// Testing the biggerElement method
		out.printf ("\nTesting the biggerElement method\n");
		Time bigger = null;
		try
		{
			bigger = memory.biggerElement ();
			out.printf("Bigger time in memory is %s\n", bigger.toString());
			assert bigger.toString().equals("23:59:59") : "Problems in the bigger method";
		}
		catch (MemoryEmptyException e)
		{
			out.printf ("%s\n", e.getMessage ());
		}

		// implement tests to verify the remaining methods
	}

	/* If the file is corrupted and being impossible to load the memory with all is useful elements the memory will not be created. */
	public static Memory<Time> loadMemoryFile () throws IOException
	{
		Scanner input = new Scanner(System.in);
		out.printf("Filename to acquire the memory? ");
		String filename = input.nextLine();		
		
		Memory<Time> memory;
		Scanner stream = new Scanner (new File (filename)); // opening the file
		int size = Integer.parseInt (stream.nextLine ()); // reading the file dimension (first line)
		int ne = Integer.parseInt (stream.nextLine ()); // reading the number of useful elements (second line)

		try
		{ memory = new Memory<Time> (size); } // creating the empty memory with the given size
		catch (NegativeArraySizeException e)
		{ out.printf ("%s\n", e.getMessage ()); stream.close (); return null; }

		for (int i = 0; i < ne; i++) // reading the time information (remaining lines)
		{
			// reading each time information and creating the Time object
			String line = stream.nextLine ();
			String [] timevalues = line.split (":");
			if (timevalues.length != 3)
			{
				stream.close ();
				out.printf ("File format incorrect\n");
				return null;
			}
			
			int hours = Integer.parseInt (timevalues[0]);
			int minutes = Integer.parseInt (timevalues[1]);
			int seconds = Integer.parseInt (timevalues[2]);

			Time time = null;
			try
			{ time = new Time (hours, minutes, seconds); }
			catch (InvalidValueException e)
			{ out.printf ("%s\n", e.getMessage ()); stream.close (); return null; }

			try
			{ memory.insert (time); } // inserting in the end of the memory
			catch (MemoryFullException e)
			{ out.printf ("%s\n", e.getMessage ()); stream.close (); return null;}
			catch (NullPointerException e)
			{ out.printf ("%s\n", e.getMessage ()); stream.close (); return null;}
		}

		stream.close (); // closing the file
		return memory; // returning the memory
	}
}
